package model;

public class Basket {
    
}
